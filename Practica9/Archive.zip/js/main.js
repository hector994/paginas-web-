$(document).on('click','#mostrar1', function(){
    Materialize.showStaggeredList('.lista1');
    Materialize.fadeInImage('.imagen1');
});
$(document).on('click','#mostrar2', function(){
    Materialize.showStaggeredList('.lista2');
    Materialize.fadeInImage('.imagen2');
});