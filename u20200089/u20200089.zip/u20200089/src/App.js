import logo from './logo.svg';
import './App.css';

function retornarAleatorio(){
  return Math.trunc(Math.random()*10)
}


function App() {
  const siglo = 21
  const persona = {nombre: 'Hector', edad: 28}

  return (

    <div className="App">
      <h1>Titulo nivel uno</h1>
      <hr></hr>
      <p>estamos en el siglo {siglo}</p>
      <h3>acceso a un objeto</h3>
      <p>{persona.nombre} tiene {persona.edad} años</p>
      <h3>hhamada a un metodo</h3>
      <p>un valor aleatorio llamando a un metodo</p>
      {retornarAleatorio()}
      <h3>Calculo inmediato de operaciones</h3>
      5+6={5+6}
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          <h1>Hector Murillo</h1>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
